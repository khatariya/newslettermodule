var config = {
    map: {
        '*': {
            'apcNewsletterPopup': 'AllPurposeCovers_NewsletterPopup/js/popup'
        }
    }
}; 