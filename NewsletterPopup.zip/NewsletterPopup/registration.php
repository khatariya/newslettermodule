<?php
use Magento\Framework\Component\ComponentRegistrar;
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'AllPurposeCovers_NewsletterPopup', __DIR__); 