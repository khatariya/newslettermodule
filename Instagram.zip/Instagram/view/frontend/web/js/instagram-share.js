define(['jquery', 'domReady!'], function($) {
    'use strict';

    // Configuration
    const config = {
        maxItems: 10,
        hashtags: ['#wishlist', '#shopping', '#style', '#favorites'],
        emojis: ['✨', '💎', '🌟', '💫', '⭐', '🎯', '💝', '🎁', '🛍️', '💖']
    };

    function initInstagramShare() {
        const $shareBtn = $('#instagram-share-btn');
        const $modal = $('#share-modal');
        const $closeModal = $('.close-modal');
        const $copyBtn = $('#copy-text-btn');
        const $instagramBtn = $('#open-instagram-btn');
        const $loading = $('#loading-indicator');

        if (!$shareBtn.length) return;

        $shareBtn.on('click', function() {
            alert('clicked');
            const customerId = $(this).data('customer-id');
            const storeName = $(this).data('store-name');
            const ajaxUrl = $(this).data('ajax-url');
            shareWishlistToInstagram(customerId, storeName, ajaxUrl);
        });

        $closeModal.on('click', closeModal);
        $modal.on('click', function(e) {
            if (e.target === this) closeModal();
        });
        $copyBtn.on('click', copyToClipboard);
        $instagramBtn.on('click', openInstagram);

        function shareWishlistToInstagram(customerId, storeName, ajaxUrl) {
            showLoading(true);
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                dataType: 'json',
                data: {
                    customer_id: customerId,
                    form_key: $('input[name="form_key"]').val()
                },
                success: function(response) {
                    if (response.success && response.items.length > 0) {
                        const content = generateInstagramContent(response.items, storeName);
                        showShareModal(content);
                    } else {
                        alert('No items found in your wishlist.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                    alert('Error loading wishlist. Please try again.');
                },
                complete: function() {
                    showLoading(false);
                }
            });
        }

        function generateInstagramContent(items, storeName) {
            let content = `🛍️ My ${storeName} Wishlist! ✨\n\n`;
            items.slice(0, config.maxItems).forEach((item, index) => {
                const emoji = config.emojis[index % config.emojis.length];
                const price = item.price > 0 ? `$${item.price}` : 'Price available in store';
                content += `${emoji} ${item.name}\n`;
                if (item.description && item.description.length > 0) {
                    content += `   ${item.description}\n`;
                }
                content += `   ${price}\n`;
                if (item.url) {
                    content += `   🔗 ${item.url}\n`;
                }
                content += '\n';
            });
            content += `\n${config.hashtags.join(' ')}\n`;
            const storeHashtag = '#' + storeName.toLowerCase().replace(/[^a-z0-9]/g, '');
            content += `\n${storeHashtag} #onlineshopping`;
            return content;
        }

        function showShareModal(content) {
            $('#share-content').text(content);
            $modal.fadeIn();
        }

        function closeModal() {
            $modal.fadeOut();
        }

        function copyToClipboard() {
            const content = $('#share-content').text();
            if (navigator.clipboard) {
                navigator.clipboard.writeText(content).then(function() {
                    $copyBtn.text('Copied!').addClass('copied');
                    setTimeout(function() {
                        $copyBtn.text('Copy Text to Clipboard').removeClass('copied');
                    }, 2000);
                }).catch(function(err) {
                    console.error('Could not copy text: ', err);
                    fallbackCopyTextToClipboard(content);
                });
            } else {
                fallbackCopyTextToClipboard(content);
            }
        }

        function fallbackCopyTextToClipboard(text) {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            try {
                document.execCommand('copy');
                $copyBtn.text('Copied!').addClass('copied');
                setTimeout(function() {
                    $copyBtn.text('Copy Text to Clipboard').removeClass('copied');
                }, 2000);
            } catch (err) {
                console.error('Fallback: Could not copy text: ', err);
            }
            document.body.removeChild(textArea);
        }

        function openInstagram() {
            const userAgent = navigator.userAgent || navigator.vendor || window.opera;
            const isAndroid = /android/i.test(userAgent);
            const isIOS = /iPad|iPhone|iPod/.test(userAgent) && !window.MSStream;
            if (isAndroid || isIOS) {
                window.location.href = 'instagram://';
                setTimeout(function() {
                    window.open('https://www.instagram.com/', '_blank');
                }, 2000);
            } else {
                window.open('https://www.instagram.com/', '_blank');
            }
        }

        function showLoading(show) {
            if (show) {
                $shareBtn.prop('disabled', true).addClass('loading');
                $loading.show();
            } else {
                $shareBtn.prop('disabled', false).removeClass('loading');
                $loading.hide();
            }
        }
    }

    $(initInstagramShare);

    return {
        init: initInstagramShare
    };
}); 