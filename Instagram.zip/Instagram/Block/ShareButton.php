<?php
/**
 * Wishlist Instagram Share Block
 */
namespace WishlistShare\Instagram\Block;

use Magento\Framework\View\Element\Template;
use Magento\Customer\Model\Session;
use Magento\Wishlist\Helper\Data as WishlistHelper;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class ShareButton extends Template
{
    /**
     * @var Session
     */
    protected $customerSession;

    /**
     * @var WishlistHelper
     */
    protected $wishlistHelper;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Constructor
     */
    public function __construct(
        Template\Context $context,
        Session $customerSession,
        WishlistHelper $wishlistHelper,
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->customerSession = $customerSession;
        $this->wishlistHelper = $wishlistHelper;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
    }

    /**
     * Check if customer is logged in
     */
    public function isCustomerLoggedIn()
    {
        return $this->customerSession->isLoggedIn();
    }

    /**
     * Get current customer ID
     */
    public function getCustomerId()
    {
        return $this->customerSession->getCustomerId();
    }

    /**
     * Get wishlist URL
     */
    public function getWishlistUrl()
    {
        return $this->wishlistHelper->getListUrl();
    }

    /**
     * Get wishlist items count
     */
    public function getWishlistItemsCount()
    {
        return $this->wishlistHelper->getItemCount();
    }

    /**
     * Get store name
     */
    public function getStoreName()
    {
        return $this->storeManager->getStore()->getName();
    }

    /**
     * Get base URL
     */
    public function getBaseUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl();
    }

    /**
     * Get AJAX URL for wishlist data
     */
    public function getAjaxUrl()
    {
        return $this->getUrl('wishlistshare/ajax/getwishlist');
    }

    /**
     * Check if module is enabled
     */
    public function isEnabled()
    {
        return true; // You can add admin configuration here
    }
}