<?php
/**
 * Wishlist Instagram Share Plugin
 * Registration file
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'WishlistShare_Instagram',
    __DIR__
);