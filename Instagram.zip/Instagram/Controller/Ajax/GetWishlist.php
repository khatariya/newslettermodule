<?php
/**
 * AJAX Controller for Wishlist Data
 */
namespace WishlistShare\Instagram\Controller\Ajax;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Customer\Model\Session;
use Magento\Wishlist\Model\WishlistFactory;
use Magento\Catalog\Helper\Image;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;

class GetWishlist extends Action implements HttpPostActionInterface
{
    /**
     * @var JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var Session
     */
    protected $customerSession;

    /**
     * @var WishlistFactory
     */
    protected $wishlistFactory;

    /**
     * @var Image
     */
    protected $imageHelper;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * Constructor
     */
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        Session $customerSession,
        WishlistFactory $wishlistFactory,
        Image $imageHelper,
        StoreManagerInterface $storeManager
    ) {
        $this->jsonFactory = $jsonFactory;
        $this->customerSession = $customerSession;
        $this->wishlistFactory = $wishlistFactory;
        $this->imageHelper = $imageHelper;
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }

    /**
     * Execute AJAX request
     */
    public function execute()
    {
        $result = $this->jsonFactory->create();
        
        // Check if customer is logged in
        if (!$this->customerSession->isLoggedIn()) {
            return $result->setData([
                'success' => false, 
                'message' => __('Customer not logged in')
            ]);
        }

        try {
            $customerId = $this->customerSession->getCustomerId();
            $wishlist = $this->wishlistFactory->create()->loadByCustomerId($customerId);
            
            $items = [];
            foreach ($wishlist->getItemCollection() as $item) {
                $product = $item->getProduct();
                
                // Get product image
                $imageUrl = $this->imageHelper
                    ->init($product, 'product_small_image')
                    ->setImageFile($product->getSmallImage())
                    ->getUrl();

                // Get product description
                $description = $product->getShortDescription();
                if ($description) {
                    $description = strip_tags($description);
                    $description = substr($description, 0, 100) . '...';
                }

                $items[] = [
                    'id' => $item->getId(),
                    'name' => $product->getName(),
                    'price' => number_format($product->getFinalPrice(), 2),
                    'url' => $product->getProductUrl(),
                    'image' => $imageUrl,
                    'description' => $description ?: '',
                    'sku' => $product->getSku()
                ];
            }

            return $result->setData([
                'success' => true,
                'items' => $items,
                'count' => count($items)
            ]);

        } catch (\Exception $e) {
            return $result->setData([
                'success' => false,
                'message' => __('Error loading wishlist: %1', $e->getMessage())
            ]);
        }
    }
}